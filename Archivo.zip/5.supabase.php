<?php
// Reutilizable para todas las llamadas
define("SUPABASE_URL", "https://ijxhqedjjbcynclultsh.supabase.co");
define("SUPABASE_API_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlqeGhxZWRqamJjeW5jbHVsdHNoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY0NDg3NjcsImV4cCI6MjA2MjAyNDc2N30.DneTKuG4TWk_zH3uhQleJgrk_TZ88hFKpSBMfOexQcI");
?>
